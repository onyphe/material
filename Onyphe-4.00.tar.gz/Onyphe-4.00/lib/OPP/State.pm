#
# $Id: State.pm,v 17cc8d9dc427 2023/03/07 06:24:43 gomor $
#
package OPP::State;
use strict;
use warnings;

our $VERSION = '1.00';

use base qw(OPP);

our @AS = qw(
   state
);
__PACKAGE__->cgBuildIndices;
__PACKAGE__->cgBuildAccessorsScalar(\@AS);

sub init {
   my $self = shift;

   $self->state({});

   return $self;
}

sub _proc {
   my $self = shift;

   my @c = caller(1);

   my $module = $c[0];
   $module =~ s{^.*::(\S+)$}{$1};

   return lc($module);
}

sub add {
   my $self = shift;
   my ($k, $v) = @_;

   return $self->state->{$self->_proc}{$k} = $v;
}

sub del {
   my $self = shift;
   my ($k) = @_;

   return delete $self->state->{$self->_proc}{$k};
}

sub exists {
   my $self = shift;
   my ($k) = @_;

   return defined($self->state->{$self->_proc}{$k}) ? 1 : 0;
}

sub incr {
   my $self = shift;
   my ($k) = @_;

   return $self->state->{$self->_proc}{$k}++;
}

sub decr {
   my $self = shift;
   my ($k) = @_;

   return $self->state->{$self->_proc}{$k}--;
}

sub value {
   my $self = shift;
   my ($k) = @_;

   return $self->state->{$self->_proc}{$k};
}

1;

__END__

=head1 NAME

OPP::State - state object for OPP's processors

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2023, Patrice E<lt>GomoRE<gt> Auffret

You may distribute this module under the terms of The BSD 3-Clause License.
See LICENSE file in the source distribution archive.

=head1 AUTHOR

Patrice E<lt>GomoRE<gt> Auffret

=cut
